package com.example.damcurvity.vo;

import com.example.damcurvity.entity.InfoStationNode;
import lombok.Data;

@Data
public class InfoStationNodeVO extends InfoStationNode {
    String stationName;
}
