package com.example.damcurvity.vo;

import com.example.damcurvity.entity.BaseEquipment;
import lombok.Data;

@Data
public class BaseEquipmentVO extends BaseEquipment {
    String acquName;
}
