package com.example.damcurvity.entity;


import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import lombok.Data;
import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
/**
 * (AlertInfo)表实体类
 *
 * @author makejava
 * @since 2023-08-05 23:43:11
 */
@Data
public class AlertInfo extends Model<AlertInfo> {
    @TableId(type = IdType.AUTO)
    @Excel(name = "id",width = 20)

    private Integer id;
    @Excel(name = "position",width = 20)

    private Integer position;
    @Excel(name = "type",width = 20)

    private String type;
    @Excel(name = "level",width = 20)

    private Integer level;
    @Excel(name = "typeNo",width = 20)

    private Integer typeNo;
    @Excel(name = "content",width = 20)

    private String content;
    @Excel(name = "time",width = 20)

    private String time;
    @Excel(name = "state",width = 20)

    private Integer state;
    @Excel(name = "remark1",width = 20)

    private String remark1;
    @Excel(name = "remark2",width = 20)

    private String remark2;
    @Excel(name = "remark3",width = 20)

    private String remark3;
    @Excel(name = "opTime1",width = 20)

    private String opTime1;
    @Excel(name = "operator1",width = 20)

    private String operator1;
    @Excel(name = "opTime2",width = 20)

    private String opTime2;
    @Excel(name = "operator2",width = 20)

    private String operator2;
    @Excel(name = "opTime3",width = 20)

    private String opTime3;
    @Excel(name = "operator3",width = 20)

    private String operator3;

}

