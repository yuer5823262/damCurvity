package com.example.damcurvity.filter;

public class UserFilter {
}
