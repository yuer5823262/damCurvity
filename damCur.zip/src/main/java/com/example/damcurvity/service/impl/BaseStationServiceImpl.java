package com.example.damcurvity.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.damcurvity.StaticSchedule.DataGetScheduleTask;
import com.example.damcurvity.dao.BaseStationDao;
import com.example.damcurvity.entity.BaseStation;
import com.example.damcurvity.excelVO.ReportExcelVO;
import com.example.damcurvity.service.BaseStationService;
import com.example.damcurvity.vo.BaseStationVO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * (BaseStation)表服务实现类
 *
 * @author makejava
 * @since 2023-08-05 16:43:53
 */
@Service("baseStationService")
public class BaseStationServiceImpl extends ServiceImpl<BaseStationDao, BaseStation> implements BaseStationService {
    @Resource
    DataGetScheduleTask dataGetScheduleTask;
    @Resource
    BaseStationDao baseStationDao;
    @Override
    public void addBaseStation(BaseStation baseStation) {
        dataGetScheduleTask.addTask(baseStation);
        this.save(baseStation);
    }

    @Override
    public Page<BaseStationVO> selectListJoin(Page<BaseStationVO> page, BaseStation baseStation) {
        return baseStationDao.selectListJoin(page,baseStation);
    }

    @Override
    public List<ReportExcelVO> exportReport(Integer jg, Integer dataType, String startTime, String endTime) {
        return baseStationDao.exportReport(jg, dataType, startTime, endTime);
    }

}

