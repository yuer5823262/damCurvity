package com.example.damcurvity.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.damcurvity.entity.Role;

/**
 * (Role)表服务接口
 *
 * @author makejava
 * @since 2023-09-24 16:14:01
 */
public interface RoleService extends IService<Role> {

}

