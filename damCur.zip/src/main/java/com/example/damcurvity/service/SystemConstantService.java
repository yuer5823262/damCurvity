package com.example.damcurvity.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.damcurvity.entity.SystemConstant;

/**
 * (SystemConstant)表服务接口
 *
 * @author makejava
 * @since 2023-08-20 08:45:28
 */
public interface SystemConstantService extends IService<SystemConstant> {

}

