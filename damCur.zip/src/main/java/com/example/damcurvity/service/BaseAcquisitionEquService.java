package com.example.damcurvity.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.damcurvity.entity.BaseAcquisitionEqu;

/**
 * (BaseAcquisitionEqu)表服务接口
 *
 * @author makejava
 * @since 2023-08-25 16:01:50
 */
public interface BaseAcquisitionEquService extends IService<BaseAcquisitionEqu> {

}

