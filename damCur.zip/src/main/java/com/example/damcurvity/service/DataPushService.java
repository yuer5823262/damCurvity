package com.example.damcurvity.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.damcurvity.entity.DataPush;

/**
 * (DataPush)表服务接口
 *
 * @author makejava
 * @since 2023-08-27 09:19:04
 */
public interface DataPushService extends IService<DataPush> {

}

