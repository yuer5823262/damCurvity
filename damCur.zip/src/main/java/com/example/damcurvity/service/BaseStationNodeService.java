package com.example.damcurvity.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.damcurvity.entity.BaseStationNode;

/**
 * (BaseStationNode)表服务接口
 *
 * @author makejava
 * @since 2023-08-05 16:43:53
 */
public interface BaseStationNodeService extends IService<BaseStationNode> {

}

