package com.example.damcurvity.req;

import lombok.Data;

@Data
public class CmdReq {
    Integer acquId;
    String name;
    String cmd;
}
