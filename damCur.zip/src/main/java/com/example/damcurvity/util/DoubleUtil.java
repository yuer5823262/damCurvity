package com.example.damcurvity.util;

public class DoubleUtil {
    public static double bl2w(double temp)
    {
        return (double) Math.round(temp * 100) / 100;
    }
}
