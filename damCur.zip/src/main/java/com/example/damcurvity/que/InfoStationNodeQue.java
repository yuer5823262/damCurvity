package com.example.damcurvity.que;

import lombok.Data;

import java.util.Date;

@Data
public class InfoStationNodeQue extends BaseQue{
    String interval;
    Integer stationId;
    Integer nodeName;
    String time;
}
