package com.example.damcurvity.que;

import lombok.Data;

@Data
public class InfoStationNodeXzQue {
    Integer interval;
    Integer zx;
    Integer stationId;
}
